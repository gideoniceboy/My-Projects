class App:
	def __init__(self):
		kys = open("key.txt","r")
		self.key = ""
		for j in kys:
			self.key += j
		self.key = str(self.key)
		# self.key = "abcdefghijklmnopqrstuvwxyz !1234567890#$%^&*(:;)<>,.|_+-=@"
		self.value = self.key[::-1]
		self.filename = "car.png" #input("Enter File Name + Extension (e.g gud.txt) : ")

		#self.machine()
		self.ImageEncryptor()

	def machine (self):
		choice = "e"
		# choice = input("Enter a Mode, Encode or Decode (E/D): ")
		if choice == "e":
			encrpt = dict(zip(self.key,self.value))

			db = open(self.filename,"r")
			words = ""
			for i in db:
				i = i.lower()
				words+=i
			words = words.lower()

			text = open(self.filename,"w")

			msg = words

			encrpts = ''.join([encrpt[word] for word in msg])
			print(encrpts)
			text.write(encrpts)
			print("Your file has been proccessed...")

	def ImageEncryptor(self):
		file = open('car.png', "rb")
		image = file.read()
		file.close()

		image = bytearray(image)
		key = 45

		for i,j in enumerate(image):
			image[i] = j^key

		file = open(self.filename,"wb")
		file.write(image)

		print("Your file has been proccessed...")

	def crypt_system(self, encrypted=False):
        system = os.walk(self.localRoot, topdown=True)
        for root, dir, files in system:
            for file in files:
                file_path = os.path.join(root, file)
                if not file.split('.')[-1] in self.file_exts:
                    continue
                if not encrypted:
                    self.crypt_file(file_path)
                else:
                    self.crypt_file(file_path, encrypted=True)


		# elif choice == "d":
		# 	kys = open("key.txt","r")
		# 	key = ""
		# 	for j in kys:
		# 		key += j

		# 	text_file = open(self.filename,"r")

		# 	encrpts = ""
		# 	for q in text_file:
		# 		encrpts += q

		# 	decrypt = dict(zip(self.value,key))
		# 	decrypts = ''.join([decrypt[letter] for letter in encrpts])
		# 	print(decrypts)
		# 	text_file = open(self.filename,"w")
		# 	text_file.write(decrypts)

	

app = App()
input()