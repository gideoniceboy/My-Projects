import curses
from curses import wrapper
import time
import random


def start_screen(stdscr):
	stdscr.clear()
	stdscr.addstr("Welcome to the G-Typing test!")
	stdscr.addstr("\nPress any key to start.")
	stdscr.refresh()
	stdscr.getkey()

def word_per_minute(stdscr,target,current,wpm):
	stdscr.addstr(target)
	stdscr.addstr(1,0,f"WPM: {wpm}")

	for i,char in enumerate(current):
		color = curses.color_pair(1)
		target_char = target[i]
		if char != target_char:
			color = curses.color_pair(2)
		stdscr.addstr(0,i,char,color)

	stdscr.refresh()
def load_text():
	with open("text.txt", "r") as f:
		lines = f.readlines()
		return random.choice(lines).strip()

def game_start(stdscr):
	current = []
	target = load_text()

	wpm = 0
	start_time = time.time()
	stdscr.nodelay(True)
	while True:
		time_elapsed = max(time.time() - start_time, 1)
		wpm = round((len(current)/(time_elapsed / 60))/5)
		stdscr.clear()
		word_per_minute(stdscr,target,current,wpm)
		stdscr.refresh()

		q = ""
		for j in current:
			q+= j

		if q == target:
			stdscr.nodelay(False)
			break

		try:
			key = stdscr.getkey()
		except:
			continue

		if ord(key) == 27:
			break
		if key in ("KEY_BACKSPACE",'\b',"\x7f"):
			if len(current) > 0:
				current.pop()
		elif len(current) < len(target):
			current.append(key)
def main(stdscr):
	curses.init_pair(1,curses.COLOR_GREEN,curses.COLOR_BLACK)
	curses.init_pair(2,curses.COLOR_RED,curses.COLOR_BLACK)
	curses.init_pair(3,curses.COLOR_WHITE,curses.COLOR_BLACK)
	start_screen(stdscr)
	
	while True:
		game_start(stdscr)
		stdscr.addstr(2,0,"The test is completed, press any Key to continue...")
		key = stdscr.getkey()
		if ord(key) == 27:
			break
	

wrapper(main)